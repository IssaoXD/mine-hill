import java.lang.reflect.*;
import net.minecraft.init.*;
import net.minecraft.block.BlockTorch;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import valter.minehill.NightTerrain;
public class TorchSmokeTest {
 static int checks;static void ok(boolean b){checks++;if(!b)throw new AssertionError("torch "+checks);}
 public static void main(String[]args)throws Exception{
  Bootstrap.register();NightTerrain terrain=new NightTerrain();Method replacement=NightTerrain.class.getDeclaredMethod("replacement",IBlockState.class);replacement.setAccessible(true);
  Class<?> entry=Class.forName("valter.minehill.NightTerrain$Entry");Constructor<?> constructor=entry.getDeclaredConstructor(BlockPos.class,IBlockState.class,IBlockState.class);constructor.setAccessible(true);Method matches=NightTerrain.class.getDeclaredMethod("matches",entry,IBlockState.class);matches.setAccessible(true);
  for(EnumFacing f:new EnumFacing[]{EnumFacing.UP,EnumFacing.NORTH,EnumFacing.SOUTH,EnumFacing.EAST,EnumFacing.WEST}){
   IBlockState normal=Blocks.TORCH.getDefaultState().withProperty(BlockTorch.FACING,f);IBlockState red=(IBlockState)replacement.invoke(terrain,normal);ok(red.getBlock()==Blocks.REDSTONE_TORCH);ok(red.getValue(BlockTorch.FACING)==f);
   Object record=constructor.newInstance(new BlockPos(0,64,0),normal,red);ok((boolean)matches.invoke(null,record,red));ok((boolean)matches.invoke(null,record,Blocks.UNLIT_REDSTONE_TORCH.getDefaultState().withProperty(BlockTorch.FACING,f)));ok(!(boolean)matches.invoke(null,record,Blocks.AIR.getDefaultState()));ok(!(boolean)matches.invoke(null,record,normal));
  }
  ok(replacement.invoke(terrain,Blocks.REDSTONE_TORCH.getDefaultState())==null);ok(replacement.invoke(terrain,Blocks.UNLIT_REDSTONE_TORCH.getDefaultState())==null);
  System.out.println(checks+" torch checks passed");
 }
}
