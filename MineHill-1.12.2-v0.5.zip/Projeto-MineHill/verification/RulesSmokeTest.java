import valter.minehill.Rules;
public class RulesSmokeTest {
 private static int count;
 private static void check(boolean b){count++;if(!b)throw new AssertionError("check "+count);}
 public static void main(String[]args){
 int dark=0;for(int t=0;t<24000;t++){if(Rules.night(t))dark++;check(Rules.night(t)==Rules.night(t+24000L));check(Rules.night(t)==Rules.night(t-24000L));}check(dark==10000);check(!Rules.night(12999));check(Rules.night(13000));check(Rules.night(22999));check(!Rules.night(23000));
 check(Rules.threat(0)==1);check(Rules.threat(32)==0);check(Rules.threat(32.01)==0);check(Rules.threat(31.99)>0);check(Rules.threat(16)==.5f);check(Rules.threat(64)==0);check(Rules.threat(1000)==0);float last=1;for(int i=0;i<=6400;i++){float v=Rules.threat(i/100.0);check(v>=0&&v<=1&&v<=last);last=v;}
 for(int c=-10000;c<=10000;c++){int r=Rules.region(c,6);check(c>=r*6&&c<r*6+6);}
 check(Rules.house(3,3));check(!Rules.house(3.01,0));
 // 48,000 simulation ticks must advance the daylight clock exactly 24,000.
 int clock=0;for(int t=1;t<=48000;t++){clock++;if(t%2==0)clock--;}check(clock==24000);

 check((Rules.darkLight(0)&0xffffff)<0x030303);check((Rules.darkLight(15)&0xff)>150);
 int previous=0;for(int level=0;level<=15;level++){int color=Rules.darkLight(level),red=(color>>16)&255;check(red>=previous);check((color>>>24)==255);previous=red;}
 // Alarm uses 300 daylight ticks = 600 game ticks with the half-speed clock.
 check(!Rules.alarmWindow(12699));check(Rules.alarmWindow(12700));check(Rules.alarmWindow(12999));check(!Rules.alarmWindow(13000));check(!Rules.alarmWindow(23000));
 int alarmTicks=0;for(int t=0;t<24000;t++){if(Rules.alarmWindow(t))alarmTicks++;check(Rules.alarmWindow(t)==Rules.alarmWindow(t+24000L));check(Rules.alarmWindow(t)==Rules.alarmWindow(t-24000L));}check(alarmTicks==300);
 int time=12699,alarmAt=-1,nightAt=-1;for(int t=1;t<=1000;t++){time++;if(t%2==0)time--;if(alarmAt<0&&Rules.alarmWindow(time))alarmAt=t;if(nightAt<0&&Rules.night(time))nightAt=t;}check(nightAt-alarmAt==600);
 check(Rules.radioLayer(false,false,false,0));check(!Rules.radioLayer(false,true,false,-4));check(Rules.radioLayer(false,true,true,-4));check(Rules.radioLayer(true,true,false,6));check(!Rules.radioLayer(true,true,true,-9));check(Rules.radioHeight(8));check(Rules.radioHeight(-8));check(!Rules.radioHeight(8.01));
 System.out.println(count+" checks passed");
 }
}
