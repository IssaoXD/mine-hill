import valter.minehill.HauntData;
import net.minecraft.nbt.*;
import net.minecraft.util.math.BlockPos;
import java.util.UUID;
/** Persistence test using the actual Minecraft NBT classes, without launching a world. */
public class StateSmokeTest {
 private static int checks;private static void check(boolean b){checks++;if(!b)throw new AssertionError("NBT check "+checks);}
 public static void main(String[] args){
  UUID a=UUID.fromString("00000000-0000-0000-0000-000000000001"),b=UUID.fromString("00000000-0000-0000-0000-000000000002");
  HauntData old=new HauntData();BlockPos home=new BlockPos(-30,65,87);old.house(home);check(old.hear(a,"house:"+home.toLong()));check(!old.hear(a,"house:"+home.toLong()));check(old.hear(b,"house:"+home.toLong()));
  NBTTagCompound legacy=old.writeToNBT(new NBTTagCompound());legacy.removeTag("watcherHomes");legacy.removeTag("spawnedWatchers");legacy.removeTag("watchersV5");legacy.removeTag("alarmDay");
  HauntData migrated=new HauntData();migrated.readFromNBT(legacy);check(migrated.alarmDay==Long.MIN_VALUE);check(migrated.houses.contains(home.toLong()));check(!migrated.hear(a,"house:"+home.toLong()));migrated.migrateWatchers();check(migrated.watcherHomes.contains(home.toLong()));
  BlockPos other=new BlockPos(41,74,-90);migrated.watcher(other);migrated.spawnedWatchers.add(home.toLong());migrated.alarmDay=7;
  HauntData restored=new HauntData();restored.readFromNBT(migrated.writeToNBT(new NBTTagCompound()));check(restored.alarmDay==7);check(restored.watcherHomes.size()==2);check(restored.spawnedWatchers.size()==1);check(restored.spawnedWatchers.contains(home.toLong()));check(!restored.spawnedWatchers.contains(other.toLong()));restored.migrateWatchers();check(restored.watcherHomes.size()==2);
  restored.reset(a);check(restored.hear(a,"house:"+home.toLong()));check(!restored.hear(b,"house:"+home.toLong()));check(restored.alarmDay==7);check(restored.spawnedWatchers.size()==1);
  System.out.println(checks+" NBT checks passed");
 }
}
