package valter.minehill;
import net.minecraft.command.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.text.TextComponentString;
public class MineHillCommand extends CommandBase {
 public String getName(){return "minehill";}
 public String getUsage(ICommandSender s){return "/minehill status | reset_sounds";}
 public int getRequiredPermissionLevel(){return 2;}
 public void execute(MinecraftServer server,ICommandSender sender,String[] args)throws CommandException{
 if(args.length==1 && args[0].equals("reset_sounds")){EntityPlayerMP p=getCommandSenderAsPlayer(sender);HauntData.get(p.getServerWorld()).reset(p.getUniqueID());sender.sendMessage(new TextComponentString("Mine Hill: seus eventos de som foram liberados novamente."));return;}
 sender.sendMessage(new TextComponentString("Mine Hill 0.5.0 beta | enabled="+Settings.enabled+" | childSoundsEnabled="+Settings.childSoundsEnabled+" | exposedTerrain=true"+" | villageRegionChunks="+Settings.regionChunks+" | maxChangesPerTick="+Settings.maxChangesPerTick));
 }
}
