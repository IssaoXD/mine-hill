package valter.minehill;
import java.io.File;
import net.minecraftforge.common.config.Configuration;
public final class Settings {
 public static int torchRadius=10;public static int scanBudget=768,surfaceDepth=4,regionChunks=6,maxChangesPerTick=24;public static double radioVolume=.5;public static boolean dynamicTorch=true;public static boolean enabled=true,childSoundsEnabled=true;
 public static void load(File f){Configuration c=new Configuration(f);c.load();
 enabled=c.getBoolean("enabled","general",true,"Enable Mine Hill in the Overworld; disabling restores loaded terrain.");
 scanBudget=c.getInt("scanBudget","terrain",768,16,8192,"Positions scanned per server tick, shared across players.");
 surfaceDepth=c.getInt("surfaceDepth","terrain",4,1,128,"Depth below surface. Deep caves stay unchanged.");
 radioVolume=c.getFloat("radioVolume","audio",.5f,0,1,"Maximum radio volume; respects Hostile Creatures slider.");
 regionChunks=c.getInt("villageRegionChunks","worldgen",6,6,64,"One abandoned settlement candidate per region. New chunks only.");childSoundsEnabled=c.getBoolean("childSoundsEnabled","audio",true,"Enable random voice events only in abandoned houses.");
 maxChangesPerTick=c.getInt("maxChangesPerTick","terrain",24,1,64,"Maximum changed or restored blocks per tick; lower means smoother but slower transitions.");
 if(!c.getBoolean("lowImpactV2Applied","general",false,"One-time migration to the lighter beta defaults.")){
 scanBudget=64;surfaceDepth=4;regionChunks=7;maxChangesPerTick=8;
 c.get("terrain","scanBudget",64).set(64);c.get("terrain","surfaceDepth",4).set(4);
 c.get("terrain","maxChangesPerTick",8).set(8);c.get("worldgen","villageRegionChunks",7).set(7);
 c.get("general","lowImpactV2Applied",false).set(true);
 }
 torchRadius=c.getInt("torchRadius","client",10,6,12,"Radius of local off-hand torch light; lower it on slower computers.");
 dynamicTorch=c.getBoolean("dynamicTorch","client",true,"Local dynamic light for a torch in the off-hand; disable if needed for performance.");
 if(!c.getBoolean("exposedV4Applied","general",false,"One-time migration to exposed terrain and six-chunk village regions.")){
 scanBudget=768;maxChangesPerTick=24;regionChunks=6;
 c.get("terrain","scanBudget",768).set(768);c.get("terrain","maxChangesPerTick",24).set(24);
 c.get("worldgen","villageRegionChunks",6).set(6);c.get("general","exposedV4Applied",false).set(true);
 }c.save();}
}
