package valter.minehill;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
/** Steve proportions; skin tiled from the game's own granite texture at runtime. */
public class StoneWatcherRenderer extends RenderLiving<StoneWatcher> {
 private ResourceLocation skin;
 public StoneWatcherRenderer(RenderManager manager){super(manager,new ModelBiped(0,0,64,64),.4f);}
 @Override protected ResourceLocation getEntityTexture(StoneWatcher e){
  if(skin==null){
   try(InputStream stream=Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("minecraft","textures/blocks/stone_granite.png")).getInputStream()){
    BufferedImage granite=ImageIO.read(stream),image=new BufferedImage(64,64,BufferedImage.TYPE_INT_ARGB);
    for(int y=0;y<64;y++)for(int x=0;x<64;x++)image.setRGB(x,y,granite.getRGB(x%granite.getWidth(),y%granite.getHeight()));
    skin=Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("minehill_granite_steve",new DynamicTexture(image));
   }catch(Exception ex){skin=new ResourceLocation("minecraft","textures/entity/steve.png");org.apache.logging.log4j.LogManager.getLogger("MineHill").warn("Could not read granite texture",ex);}
  }return skin;
 }
}
