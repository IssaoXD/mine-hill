package valter.minehill;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
/** Persistent statue: inert and indestructible by day, a melee pursuer at night. */
public class StoneWatcher extends EntityCreature implements IMob {
 public StoneWatcher(World w){super(w);setSize(.6f,1.8f);enablePersistence();experienceValue=0;}
 @Override protected void initEntityAI(){
  tasks.addTask(0,new EntityAISwimming(this));
  tasks.addTask(1,new EntityAIAttackMelee(this,1.0,true));
  tasks.addTask(2,new EntityAIMoveTowardsRestriction(this,1.0));
  targetTasks.addTask(0,new EntityAIHurtByTarget(this,false));
  targetTasks.addTask(1,new EntityAINearestAttackableTarget<EntityPlayer>(this,EntityPlayer.class,true));
 }
 @Override protected void applyEntityAttributes(){super.applyEntityAttributes();getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(30);getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(.23);getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(24);getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3);getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(1);}
 public boolean awake(){return Settings.enabled && world.provider.getDimension()==0 && Rules.night(world.getWorldTime()) && world.getDifficulty()!=EnumDifficulty.PEACEFUL;}
 @Override public void onLivingUpdate(){
  boolean moving=awake();
  if(!world.isRemote){setNoAI(!moving);if(!moving){setAttackTarget(null);getNavigator().clearPath();}}
  double x=posX,y=posY,z=posZ;float yaw=rotationYaw,pitch=rotationPitch;
  super.onLivingUpdate();
  if(!moving){motionX=motionY=motionZ=0;setPosition(x,y,z);rotationYaw=prevRotationYaw=yaw;rotationPitch=prevRotationPitch=pitch;renderYawOffset=prevRenderYawOffset=yaw;rotationYawHead=prevRotationYawHead=yaw;limbSwingAmount=prevLimbSwingAmount=0;}
  if(isBurning())extinguish();
 }
 @Override public boolean attackEntityFrom(DamageSource source,float amount){return awake() && super.attackEntityFrom(source,amount);}
 @Override public boolean attackEntityAsMob(Entity target){return awake() && target.attackEntityFrom(DamageSource.causeMobDamage(this),(float)getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue());}
 @Override public boolean canBePushed(){return awake();}
 @Override public void applyEntityCollision(Entity other){if(awake())super.applyEntityCollision(other);}
 @Override protected boolean canDespawn(){return false;}
 @Override public boolean isPushedByWater(){return awake();}
 /** Two statues per pass at most; never load chunks to place one. */
 private static final java.util.Map<World,java.util.Set<Long>> inspected=new java.util.WeakHashMap<>();
 private static void discoverExisting(WorldServer w,HauntData data){
  java.util.Set<Long> seen=inspected.computeIfAbsent(w,k->new java.util.HashSet<>());
  for(EntityPlayer player:w.playerEntities)for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++){
   int cx=player.chunkCoordX+dx,cz=player.chunkCoordZ+dz;long key=net.minecraft.util.math.ChunkPos.asLong(cx,cz);if(seen.contains(key)||w.getChunkProvider().getLoadedChunk(cx,cz)==null)continue;seen.add(key);
   int size=Settings.regionChunks,rx=Rules.region(cx,size),rz=Rules.region(cz,size);java.util.Random r=new java.util.Random(w.getSeed()^(rx*341873128712L)^(rz*132897987541L));
   int tx=rx*size+1+r.nextInt(size-2),tz=rz*size+1+r.nextInt(size-2),a=cx-tx,b=cz-tz;
   if(Math.abs(a)<=1 && Math.abs(b)<=1 && (a!=0||b!=0)){
    boolean church=a==-1&&b==-1;int x=cx*16+3,z=cz*16+(church?11:3);
    for(int y=1;y<250;y++){BlockPos marker=new BlockPos(x,y,z);if(w.getBlockState(marker).getBlock()==(church?net.minecraft.init.Blocks.STONE_SLAB:net.minecraft.init.Blocks.CRAFTING_TABLE)){data.watcher(new BlockPos(cx*16+(church?5:4),y,cz*16+4));break;}}
   }
   return; // At most one old chunk inspected per second, no extra generation.
  }
 }
 public static void populate(WorldServer w,HauntData data){
  discoverExisting(w,data);
  data.migrateWatchers();int added=0;
  for(long key:data.watcherHomes){if(data.spawnedWatchers.contains(key))continue;BlockPos pos=BlockPos.fromLong(key);
   if(w.getChunkProvider().getLoadedChunk(pos.getX()>>4,pos.getZ()>>4)==null)continue;
   boolean near=false;for(EntityPlayer p:w.playerEntities)if(p.getDistanceSq(pos)<4096){near=true;break;}if(!near)continue;
   StoneWatcher entity=new StoneWatcher(w);entity.setLocationAndAngles(pos.getX()+.5,pos.getY(),pos.getZ()+.5,180,0);
   if(!w.getCollisionBoxes(entity,entity.getEntityBoundingBox()).isEmpty() || w.containsAnyLiquid(entity.getEntityBoundingBox()))continue;
   if(w.spawnEntity(entity)){data.spawnedWatchers.add(key);data.markDirty();if(++added>=2)break;}
  }
 }
}
