package valter.minehill;
import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.structure.MapGenVillage;
import net.minecraftforge.event.terraingen.InitMapGenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.IWorldGenerator;
/** A complete ruined settlement spread over nine independently generated chunks. */
public class Villages implements IWorldGenerator {
 @SubscribeEvent public void village(InitMapGenEvent e){if(Settings.enabled && e.getType()==InitMapGenEvent.EventType.VILLAGE)e.setNewGen(new NoVillage());}
 public static class NoVillage extends MapGenVillage {@Override protected boolean canSpawnStructureAtCoords(int x,int z){return false;}}
 public void generate(Random ignored,int cx,int cz,World w,IChunkGenerator gen,IChunkProvider provider){
  if(!Settings.enabled || w.provider.getDimension()!=0)return;
  int size=Settings.regionChunks,rx=Rules.region(cx,size),rz=Rules.region(cz,size);
  Random layout=new Random(w.getSeed() ^ (rx*341873128712L) ^ (rz*132897987541L));
  // Leave one chunk of margin so all nine pieces remain within their own region.
  int tx=rx*size+1+layout.nextInt(size-2),tz=rz*size+1+layout.nextInt(size-2);
  int dx=cx-tx,dz=cz-tz;if(Math.abs(dx)>1 || Math.abs(dz)>1)return;
  int x=cx*16,z=cz*16,min=256,max=0;
  for(int a=1;a<=14;a+=3)for(int b=1;b<=14;b+=3){BlockPos top=surface(w,x+a,z+b);
   if(w.getBlockState(top).getMaterial().isLiquid() || top.getY()<50 || top.getY()>220)return;
   min=Math.min(min,top.getY());max=Math.max(max,top.getY());
  }if(max-min>6)return;
  Random r=new Random(w.getSeed() ^ (cx*374761393L) ^ (cz*668265263L));
  // Only touch this chunk. Never request generation of neighbouring chunks.
  for(int k=0;k<16;k++)for(int width=7;width<=8;width++){
   path(w,x+k,z+width);path(w,x+width,z+k);
  }
  if(dx==0 && dz==0){well(w,x+5,z+5);farm(w,x+1,z+1,r);farm(w,x+10,z+10,r);}
  else if(dx==-1 && dz==-1)church(w,x+1,z+1,r);
  else {house(w,x+1,z+1,r,(dx+dz)&1);farm(w,x+10,z+10,r);}
 }
 private BlockPos surface(World w,int x,int z){BlockPos p=w.getHeight(new BlockPos(x,0,z)).down();
  while(p.getY()>1){IBlockState s=w.getBlockState(p);Block b=s.getBlock();Material m=s.getMaterial();
   if(b!=Blocks.LEAVES && b!=Blocks.LEAVES2 && b!=Blocks.LOG && b!=Blocks.LOG2 && m!=Material.PLANTS && m!=Material.VINE && m!=Material.AIR)break;p=p.down();
  }return p;
 }
 private void put(World w,int x,int y,int z,IBlockState state){w.setBlockState(new BlockPos(x,y,z),state,2);}
 private void path(World w,int x,int z){BlockPos p=surface(w,x,z);if(!w.getBlockState(p).getMaterial().isLiquid()){w.setBlockState(p,Blocks.GRAVEL.getDefaultState(),2);for(int dy=1;dy<=3;dy++)put(w,x,p.getY()+dy,z,Blocks.AIR.getDefaultState());}}
 private int floor(World w,int x,int z,int width,int depth){int y=0;
  for(int a=0;a<width;a++)for(int b=0;b<depth;b++)y=Math.max(y,surface(w,x+a,z+b).getY()+1);
  for(int a=0;a<width;a++)for(int b=0;b<depth;b++){
   int ground=surface(w,x+a,z+b).getY();for(int yy=ground+1;yy<y;yy++)put(w,x+a,yy,z+b,Blocks.COBBLESTONE.getDefaultState());
   put(w,x+a,y,z+b,Blocks.MOSSY_COBBLESTONE.getDefaultState());
  }return y;
 }
 private void house(World w,int x,int z,Random r,int style){int width=6,depth=6,y=floor(w,x,z,width,depth);
  for(int a=0;a<width;a++)for(int b=0;b<depth;b++){
   for(int dy=1;dy<=4;dy++){
    boolean wall=a==0||b==0||a==width-1||b==depth-1,door=a==width-1 && b==3 && dy<=2;
    IBlockState state=Blocks.AIR.getDefaultState();
    if(wall && !door && r.nextInt(12)!=0){state=(dy==1?Blocks.COBBLESTONE:Blocks.PLANKS).getDefaultState();
     if(dy==2 && (a==2||b==2))state=r.nextBoolean()?Blocks.GLASS_PANE.getDefaultState():Blocks.AIR.getDefaultState();}
    put(w,x+a,y+dy,z+b,state);
   }
   put(w,x+a,y+5,z+b,r.nextInt(7)==0?Blocks.AIR.getDefaultState():(style==0?Blocks.COBBLESTONE:Blocks.PLANKS).getDefaultState());
  }
  put(w,x+1,y+1,z+1,Blocks.WEB.getDefaultState());put(w,x+1,y+3,z+4,Blocks.WEB.getDefaultState());
  put(w,x+2,y+1,z+2,Blocks.CRAFTING_TABLE.getDefaultState());
  put(w,x+1,y+1,z+3,(style==0?Blocks.FURNACE:Blocks.BOOKSHELF).getDefaultState());
  // Stone steps connect the raised floor to the road without crossing chunk bounds.
  put(w,x+6,y-1,z+3,Blocks.COBBLESTONE.getDefaultState());
  HauntData.get(w).watcher(new BlockPos(x+3,y+1,z+3));
  if(r.nextBoolean())HauntData.get(w).house(new BlockPos(x+3,y+1,z+3));
 }
 private void church(World w,int x,int z,Random r){int y=floor(w,x,z,6,12);
  for(int a=0;a<6;a++)for(int b=0;b<12;b++)for(int dy=1;dy<=6;dy++){
   boolean edge=a==0||a==5||b==0||b==11,door=a==5&&b==3&&dy<=2;
   IBlockState state=Blocks.AIR.getDefaultState();
   if((edge&&!door)||dy==6){state=Blocks.MOSSY_COBBLESTONE.getDefaultState();if(r.nextInt(17)==0)state=Blocks.AIR.getDefaultState();}
   if(edge&&dy==3&&(b==4||b==8))state=Blocks.GLASS_PANE.getDefaultState();
   put(w,x+a,y+dy,z+b,state);
  }
  for(int a=1;a<=4;a++)for(int b=1;b<=4;b++)for(int dy=7;dy<=9;dy++)if(a==1||a==4||b==1||b==4)put(w,x+a,y+dy,z+b,Blocks.COBBLESTONE.getDefaultState());
  for(int b=5;b<=9;b+=2)for(int a=1;a<=3;a++)put(w,x+a,y+1,z+b,Blocks.OAK_STAIRS.getDefaultState());
  HauntData.get(w).watcher(new BlockPos(x+4,y+1,z+3));
  put(w,x+2,y+1,z+10,Blocks.STONE_SLAB.getDefaultState());put(w,x+1,y+3,z+2,Blocks.WEB.getDefaultState());
 }
 private void well(World w,int x,int z){int y=floor(w,x,z,5,5);
  for(int a=0;a<5;a++)for(int b=0;b<5;b++){
   boolean edge=a==0||b==0||a==4||b==4;put(w,x+a,y+1,z+b,edge?Blocks.COBBLESTONE.getDefaultState():Blocks.WATER.getDefaultState());
   if((a==0||a==4)&&(b==0||b==4))for(int dy=2;dy<=4;dy++)put(w,x+a,y+dy,z+b,Blocks.OAK_FENCE.getDefaultState());
   if((a+b)%4!=0)put(w,x+a,y+5,z+b,Blocks.COBBLESTONE.getDefaultState());
  }
 }
 private void farm(World w,int x,int z,Random r){int y=surface(w,x+2,z+2).getY();
  for(int a=0;a<4;a++)for(int b=0;b<4;b++){
   put(w,x+a,y,z+b,(a==0?Blocks.WATER:Blocks.FARMLAND).getDefaultState());
   put(w,x+a,y+1,z+b,a>0&&r.nextInt(4)!=0?Blocks.WHEAT.getDefaultState().withProperty(BlockCrops.AGE,r.nextInt(8)):Blocks.AIR.getDefaultState());
  }
 }
}
