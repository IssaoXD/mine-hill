package valter.minehill;
public final class Rules {
 public static boolean night(long time){long t=Math.floorMod(time,24000L);return t>=13000 && t<23000;}
 public static boolean alarmWindow(long time){long t=Math.floorMod(time,24000L);return t>=12700 && t<13000;}
 public static boolean radioHeight(double dy){return Math.abs(dy)<=8;}
 public static boolean radioLayer(boolean playerUnder,boolean mobUnder,boolean visible,double dy){return radioHeight(dy) && (playerUnder==mobUnder || visible);}
 public static float threat(double distance){return distance>=32?0:(float)Math.max(0,Math.min(1,1-distance/32));}
 public static boolean house(double dx,double dz){return Math.abs(dx)<=3 && Math.abs(dz)<=3;}
 public static int darkLight(int level){float b=(float)Math.pow(Math.max(0,Math.min(15,level))/15.0,1.6);return 0xff000000 | (Math.round(1+254*b)<<16) | (Math.round(1+234*b)<<8) | Math.round(2+208*b);}
 public static int region(int chunk,int size){return Math.floorDiv(chunk,size);}
}
