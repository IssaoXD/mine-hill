package valter.minehill;
public class CommonProxy { public void init(){} public void receive(float threat,int cue){} }
