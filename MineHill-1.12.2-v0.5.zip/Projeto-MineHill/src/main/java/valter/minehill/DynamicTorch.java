package valter.minehill;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumSkyBlock;
/** Small client-only light field. No blocks or server light/spawn rules are changed. */
final class DynamicTorch {
 private static class Saved {int before,applied;Saved(int b,int a){before=b;applied=a;}}
 private WorldClient world;private BlockPos origin;private int ticks;private final Map<BlockPos,Saved> saved=new HashMap<>();
 void tick(Minecraft mc,boolean active){
  boolean held=active && Settings.dynamicTorch && mc.player!=null && !mc.player.isSpectator()
   && mc.player.getHeldItemOffhand().getItem()==Item.getItemFromBlock(Blocks.TORCH);
  if(!held || world!=mc.world){clear();world=held?mc.world:null;origin=null;}
  if(!held || mc.world==null)return;world=mc.world;
  BlockPos now=mc.player.getPosition().up();ticks++;
  if(origin!=null && (ticks%8!=0 || (origin.equals(now) && ticks%80!=0)))return;
  BlockPos old=origin;restore();origin=now;
  Map<BlockPos,Integer> levels=new HashMap<>();ArrayDeque<BlockPos> queue=new ArrayDeque<>();
  if(world.isBlockLoaded(now)){levels.put(now,14);queue.add(now);}
  while(!queue.isEmpty()){
   BlockPos p=queue.removeFirst();int level=levels.get(p);if(level<=2)continue;
   for(EnumFacing f:EnumFacing.values()){
    BlockPos q=p.offset(f);if(q.getY()<1 || q.getY()>254 || !world.isBlockLoaded(q))continue;
    int distance=Math.abs(q.getX()-now.getX())+Math.abs(q.getY()-now.getY())+Math.abs(q.getZ()-now.getZ());if(distance>Settings.torchRadius)continue;
    int opacity=world.getBlockState(q).getLightOpacity(world,q);if(opacity>=15)continue;
    int next=level-Math.max(1,opacity);if(next<=0 || next<=levels.getOrDefault(q,0))continue;
    levels.put(q,next);queue.addLast(q);
   }
  }
  for(Map.Entry<BlockPos,Integer> e:levels.entrySet()){
   BlockPos p=e.getKey();int before=world.getLightFor(EnumSkyBlock.BLOCK,p),target=Math.max(before,e.getValue());
   if(target>before){saved.put(p,new Saved(before,target));world.getChunkFromBlockCoords(p).setLightFor(EnumSkyBlock.BLOCK,p,target);}
  }
  redraw(old,now);
 }
 private void restore(){if(world==null){saved.clear();return;}
  for(Map.Entry<BlockPos,Saved> e:saved.entrySet()){
   BlockPos p=e.getKey();if(!world.isBlockLoaded(p))continue;Saved s=e.getValue();
   if(world.getLightFor(EnumSkyBlock.BLOCK,p)==s.applied){int nativeLight=Math.max(s.before,world.getBlockState(p).getLightValue(world,p));world.getChunkFromBlockCoords(p).setLightFor(EnumSkyBlock.BLOCK,p,nativeLight);}
  }saved.clear();
 }
 private void redraw(BlockPos a,BlockPos b){if(world==null || (a==null && b==null))return;if(a==null)a=b;if(b==null)b=a;
  if(Math.abs(a.getX()-b.getX())+Math.abs(a.getY()-b.getY())+Math.abs(a.getZ()-b.getZ())>24){redraw(a,a);redraw(b,b);return;}
  int radius=Settings.torchRadius+1;world.markBlockRangeForRenderUpdate(Math.min(a.getX(),b.getX())-radius,Math.min(a.getY(),b.getY())-radius,Math.min(a.getZ(),b.getZ())-radius,
   Math.max(a.getX(),b.getX())+radius,Math.max(a.getY(),b.getY())+radius,Math.max(a.getZ(),b.getZ())+radius);
 }
 private void clear(){restore();redraw(origin,null);saved.clear();origin=null;}
}
