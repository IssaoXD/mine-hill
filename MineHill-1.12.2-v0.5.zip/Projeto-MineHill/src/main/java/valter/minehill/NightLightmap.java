package valter.minehill;
import java.lang.reflect.Field;
import java.util.Arrays;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
/** Darkness removes sky contribution while preserving actual block and torch light. */
final class NightLightmap {
 private DynamicTexture texture;private int[] vanilla,custom;private boolean attempted,applied;
 private void find(Minecraft mc){if(attempted)return;attempted=true;
  try{for(Field f:EntityRenderer.class.getDeclaredFields())if(DynamicTexture.class.isAssignableFrom(f.getType())){
   f.setAccessible(true);DynamicTexture candidate=(DynamicTexture)f.get(mc.entityRenderer);
   if(candidate!=null && candidate.getTextureData().length==256){texture=candidate;return;}
  }}catch(ReflectiveOperationException | SecurityException ex){org.apache.logging.log4j.LogManager.getLogger("MineHill").warn("Could not access the vanilla night lightmap",ex);}
 }
 void apply(Minecraft mc){find(mc);if(texture==null)return;int[] pixels=texture.getTextureData();
  // The vanilla renderer refreshes this array periodically. Keep its last unmodified image.
  if(custom==null || !Arrays.equals(pixels,custom))vanilla=pixels.clone();
  if(custom==null){custom=new int[256];for(int i=0;i<256;i++)custom[i]=Rules.darkLight(i&15);}
  System.arraycopy(custom,0,pixels,0,256);texture.updateDynamicTexture();applied=true;
 }
 void reset(Minecraft mc){if(applied && texture!=null && vanilla!=null){System.arraycopy(vanilla,0,texture.getTextureData(),0,256);texture.updateDynamicTexture();}applied=false;}
}
