package valter.minehill;
import java.util.*;
import net.minecraft.nbt.*;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraft.util.math.BlockPos;
public class HauntData extends WorldSavedData {
 public final Set<Long> houses=new HashSet<>();public final Set<Long> watcherHomes=new HashSet<>(),spawnedWatchers=new HashSet<>();public long alarmDay=Long.MIN_VALUE;private boolean migratedWatchers;
 private final Set<String> heard=new HashSet<>();
 public HauntData(){super("minehill_haunts");}public HauntData(String n){super(n);}
 public static HauntData get(World w){HauntData d=(HauntData)w.getPerWorldStorage().getOrLoadData(HauntData.class,"minehill_haunts");if(d==null){d=new HauntData();w.getPerWorldStorage().setData("minehill_haunts",d);}return d;}
 public boolean hear(UUID u,String key){boolean fresh=heard.add(u+":"+key);if(fresh)markDirty();return fresh;}
 public void reset(java.util.UUID u){heard.removeIf(s->s.startsWith(u.toString()+":"));markDirty();}
 public void house(BlockPos p){houses.add(p.toLong());markDirty();}
 public void watcher(BlockPos p){watcherHomes.add(p.toLong());markDirty();}
 public void migrateWatchers(){if(!migratedWatchers){watcherHomes.addAll(houses);migratedWatchers=true;markDirty();}}
 public void readFromNBT(NBTTagCompound n){houses.clear();heard.clear();watcherHomes.clear();spawnedWatchers.clear();migratedWatchers=n.getBoolean("watchersV5");alarmDay=n.hasKey("alarmDay")?n.getLong("alarmDay"):Long.MIN_VALUE;NBTTagList hs=n.getTagList("watcherHomes",4);for(int i=0;i<hs.tagCount();i++)watcherHomes.add(((NBTTagLong)hs.get(i)).getLong());hs=n.getTagList("spawnedWatchers",4);for(int i=0;i<hs.tagCount();i++)spawnedWatchers.add(((NBTTagLong)hs.get(i)).getLong());NBTTagList a=n.getTagList("houses",4);for(int i=0;i<a.tagCount();i++)houses.add(((NBTTagLong)a.get(i)).getLong());a=n.getTagList("heard",8);for(int i=0;i<a.tagCount();i++)heard.add(a.getStringTagAt(i));}
 public NBTTagCompound writeToNBT(NBTTagCompound n){NBTTagList a=new NBTTagList();for(long p:houses)a.appendTag(new NBTTagLong(p));n.setTag("houses",a);a=new NBTTagList();for(String s:heard)a.appendTag(new NBTTagString(s));n.setTag("heard",a);a=new NBTTagList();for(long h:watcherHomes)a.appendTag(new NBTTagLong(h));n.setTag("watcherHomes",a);a=new NBTTagList();for(long h:spawnedWatchers)a.appendTag(new NBTTagLong(h));n.setTag("spawnedWatchers",a);n.setBoolean("watchersV5",migratedWatchers);n.setLong("alarmDay",alarmDay);return n;}
}
