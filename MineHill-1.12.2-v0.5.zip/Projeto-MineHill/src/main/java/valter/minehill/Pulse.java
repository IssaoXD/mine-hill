package valter.minehill;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.*;
public class Pulse implements IMessage {
 public float threat;public int cue;
 public Pulse(){}public Pulse(float v,int c){threat=v;cue=c;}
 public void fromBytes(ByteBuf b){threat=b.readFloat();cue=b.readByte();}
 public void toBytes(ByteBuf b){b.writeFloat(threat);b.writeByte(cue);}
 public static class Handler implements IMessageHandler<Pulse,IMessage>{public IMessage onMessage(Pulse m,MessageContext c){MineHill.proxy.receive(m.threat,m.cue);return null;}}
}
