package valter.minehill;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.util.DamageSource;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.world.IBlockAccess;
import javax.annotation.Nullable;
public final class NightWater extends Block {
 public NightWater(){super(Material.PORTAL);setRegistryName(MineHill.ID,"night_water");setUnlocalizedName("minehill.night_water");setLightLevel(.8f);setHardness(-1f);setResistance(6000000f);}
 @Override public boolean isOpaqueCube(IBlockState s){return false;}
 @Override public boolean isFullCube(IBlockState s){return false;}
 @Override @Nullable public AxisAlignedBB getCollisionBoundingBox(IBlockState s,IBlockAccess w,BlockPos p){return NULL_AABB;}
 @Override public void onEntityCollidedWithBlock(World w,BlockPos p,IBlockState s,Entity e){if(!w.isRemote && !e.isImmuneToFire() && e.ticksExisted%10==0)e.attackEntityFrom(DamageSource.LAVA,4f);}
 @Override public BlockRenderLayer getBlockLayer(){return BlockRenderLayer.TRANSLUCENT;}
 @Override public int quantityDropped(java.util.Random r){return 0;}
}
