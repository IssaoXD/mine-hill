package valter.minehill;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.monster.*;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.WorldServer;
/** Works only with already loaded terrain; caps additional mobs for slower machines. */
public final class NightMobs {
 private static final String TAG="MineHillExtraSpawn";
 private NightMobs(){}
 private static boolean extra(Entity e){return e.getEntityData().getBoolean(TAG)||e.getEntityData().getBoolean("MineHillNightSpawn");}
 private static boolean nightExtra(Entity e){return e.getEntityData().getBoolean("MineHillNightSpawn")||e.getEntityData().getBoolean("MineHillSpawnedAtNight");}
 public static void update(WorldServer w){
  // Run after entity AI: clear daylight ignition before the next damage tick.
  if(w.isDaytime())for(Entity e:w.loadedEntityList){
   if((e instanceof EntityZombie || e instanceof AbstractSkeleton) && e.isBurning()
      && w.canSeeSky(new BlockPos(e.posX,e.posY+e.height*.85,e.posZ)))e.extinguish();
  }
  boolean night=Rules.night(w.getWorldTime());
  if(w.getTotalWorldTime()%200!=0
     || w.getDifficulty()==EnumDifficulty.PEACEFUL || !w.getGameRules().getBoolean("doMobSpawning"))return;
  int total=0,all=0;for(Entity e:w.loadedEntityList)if(e.isEntityAlive() && extra(e)){all++;if(nightExtra(e)==night)total++;}
  if(total>=6 || all>=12)return;
  for(EntityPlayer player:w.playerEntities){
   if(player.isSpectator() || !player.isEntityAlive())continue;
   int nearby=0,hostiles=0;
   for(Entity e:w.getEntitiesWithinAABB(Entity.class,player.getEntityBoundingBox().grow(48),x->x!=null && x.isEntityAlive() && x instanceof IMob)){
    hostiles++;if(extra(e) && nightExtra(e)==night)nearby++;
   }
   if(nearby>=3 || hostiles>=40)continue;
   for(int attempt=0;attempt<8;attempt++){
    double angle=w.rand.nextDouble()*Math.PI*2,dist=20+w.rand.nextInt(13);
    int x=(int)Math.floor(player.posX+Math.cos(angle)*dist),z=(int)Math.floor(player.posZ+Math.sin(angle)*dist);
    if((x&15)<3 || (x&15)>12 || (z&15)<3 || (z&15)>12)continue;
    if(w.getChunkProvider().getLoadedChunk(x>>4,z>>4)==null)continue;
    BlockPos pos=w.getHeight(new BlockPos(x,0,z));
    if(pos.getY()<2 || pos.getY()>250 || !w.getBlockState(pos.down()).isSideSolid(w,pos.down(),net.minecraft.util.EnumFacing.UP))continue;
    boolean close=false;for(EntityPlayer other:w.playerEntities)if(other.getDistanceSq(pos)<256){close=true;break;}if(close)continue;
    int kind=w.rand.nextInt(night?3:4);
    EntityLiving mob=night?(kind==0?new EntityWitherSkeleton(w):kind==1?new EntityMagmaCube(w):new EntityBlaze(w)):(kind==0?new EntityZombie(w):kind==1?new EntitySkeleton(w):kind==2?new EntitySpider(w):new EntityCreeper(w));
    mob.setLocationAndAngles(x+.5,pos.getY(),z+.5,w.rand.nextFloat()*360,0);
    mob.onInitialSpawn(w.getDifficultyForLocation(pos),null);
    if(!w.getCollisionBoxes(mob,mob.getEntityBoundingBox()).isEmpty()
       || !w.checkNoEntityCollision(mob.getEntityBoundingBox()) || w.containsAnyLiquid(mob.getEntityBoundingBox()))continue;
    if(net.minecraftforge.event.ForgeEventFactory.canEntitySpawn(mob,w,(float)mob.posX,(float)mob.posY,(float)mob.posZ,false)==net.minecraftforge.fml.common.eventhandler.Event.Result.DENY)continue;
    mob.getEntityData().setBoolean(TAG,true);mob.getEntityData().setBoolean("MineHillSpawnedAtNight",night);
    if(w.spawnEntity(mob)){total++;all++;break;}
   }
   if(total>=6 || all>=12)break;
  }
 }
}
