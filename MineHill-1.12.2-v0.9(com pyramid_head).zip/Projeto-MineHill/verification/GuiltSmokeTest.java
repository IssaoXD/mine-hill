import valter.minehill.*;
import net.minecraft.nbt.NBTTagCompound;
import java.util.UUID;
public final class GuiltSmokeTest {
 static int checks;static void ok(boolean b){checks++;if(!b)throw new AssertionError("guilt "+checks);}
 static void kills(GuiltData d,UUID u,int n,long t){for(int i=0;i<n;i++)d.kill(u,t);}
 public static void main(String[]args){
 UUID a=new UUID(1,1),b=new UUID(2,2),mob=new UUID(3,3);GuiltData d=new GuiltData();
 kills(d,a,4,1000);ok(!d.active(a));d.kill(a,1000);ok(d.active(a));ok(GuiltRules.speed(5)==.25);d.kill(a,1000);ok(GuiltRules.speed(d.entry(a).kills)==GuiltRules.speed(6));d.kill(a,1000);ok(GuiltRules.speed(d.entry(a).kills)==GuiltRules.speed(7));
 d.assign(a,mob);d.defeated(a,new UUID(4,4),100);ok(d.entry(a).respawnAt==0);d.defeated(a,mob,100);ok(d.active(a));ok(d.entry(a).entity==null);ok(d.entry(a).respawnAt==1300);
 GuiltData r=new GuiltData();r.readFromNBT(d.writeToNBT(new NBTTagCompound()));ok(r.active(a));ok(r.entry(a).respawnAt==1300);r.phase(12700);ok(!r.active(a));r.kill(a,14000);ok(r.entry(a)==null);
 d=new GuiltData();kills(d,a,10,1000);kills(d,b,9,1000);d.phase(12700);ok(d.active(a));ok(!d.active(b));ok(d.entry(a).kills==5);ok(d.allowed(a,14000));ok(GuiltRules.speed(d.entry(a).kills)==.25);
 r=new GuiltData();r.readFromNBT(d.writeToNBT(new NBTTagCompound()));ok(r.entry(a).carried);r.phase(23000);ok(r.active(a));r.phase(24000);ok(r.active(a));r.phase(36700);ok(!r.active(a));
 d.kill(a,24000);kills(d,a,9,24000);d.phase(36700);ok(d.allowed(a,38000));kills(d,a,2,38000);ok(d.entry(a).kills==7);kills(d,a,3,48000);ok(d.entry(a).kills==10);d.phase(60700);ok(d.entry(a).kills==5);d.phase(108700);ok(!d.active(a));
 d=new GuiltData();kills(d,a,5,1000);d.assign(a,mob);d.defeated(a,mob,100);d.phase(12700);ok(d.entry(a)==null);
 d=new GuiltData();kills(d,a,10,1000);d.assign(a,mob);d.defeated(a,mob,100);d.phase(12700);ok(d.entry(a).respawnAt==1300);ok(d.allowed(a,14000));
 ok(GuiltRules.speed(17)==.5);ok(GuiltRules.speed(Integer.MAX_VALUE)==.5);
 for(int n=5;n<11;n++){ok(GuiltRules.speed(n)<.5);ok(Math.abs(GuiltRules.speed(n+1)-GuiltRules.speed(n)-(.25/6))<1e-12);}
 ok(GuiltRules.speed(11)==.5);
 for(int n=0;n<100;n++){ok(GuiltRules.speed(n)<=.5);ok(Double.isFinite(GuiltRules.speed(n)));ok(GuiltRules.speed(n)>=.25);ok(GuiltRules.triggered(n)==(n>=5));}
 ok(GuiltRules.next(Integer.MAX_VALUE)==Integer.MAX_VALUE);System.out.println(checks+" guilt checks passed");
 }
}
