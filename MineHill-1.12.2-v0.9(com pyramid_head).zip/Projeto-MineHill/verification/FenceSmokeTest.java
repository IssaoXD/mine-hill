import java.lang.reflect.*;
import net.minecraft.init.*;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import valter.minehill.NightTerrain;
public class FenceSmokeTest {
 public static void main(String[] args)throws Exception {
  Bootstrap.register();NightTerrain terrain=new NightTerrain();
  Method replacement=NightTerrain.class.getDeclaredMethod("replacement",IBlockState.class);replacement.setAccessible(true);
  Class<?> entry=Class.forName("valter.minehill.NightTerrain$Entry");
  Constructor<?> constructor=entry.getDeclaredConstructor(BlockPos.class,IBlockState.class,IBlockState.class);constructor.setAccessible(true);
  Method matches=NightTerrain.class.getDeclaredMethod("matches",entry,IBlockState.class);matches.setAccessible(true);
  int checks=0;
  for(net.minecraft.block.Block block:new net.minecraft.block.Block[]{Blocks.OAK_FENCE,Blocks.SPRUCE_FENCE,Blocks.BIRCH_FENCE,Blocks.JUNGLE_FENCE,Blocks.ACACIA_FENCE,Blocks.DARK_OAK_FENCE}){
   IBlockState before=block.getDefaultState(),after=(IBlockState)replacement.invoke(terrain,before);
   if(after.getBlock()!=Blocks.IRON_BARS)throw new AssertionError("Wrong fence conversion");checks++;
   Object snapshot=constructor.newInstance(new BlockPos(0,64,0),before,after);
   if(!(boolean)matches.invoke(null,snapshot,after))throw new AssertionError("Cannot restore converted fence");checks++;
   if((boolean)matches.invoke(null,snapshot,Blocks.AIR.getDefaultState()))throw new AssertionError("Would resurrect mined block");checks++;
  }
  if(replacement.invoke(terrain,Blocks.NETHER_BRICK_FENCE.getDefaultState())!=null)throw new AssertionError("Nether fence must stay unchanged");checks++;
  if(replacement.invoke(terrain,Blocks.OAK_FENCE_GATE.getDefaultState())!=null)throw new AssertionError("Fence gate must stay unchanged");checks++;
  System.out.println(checks+" fence checks passed");
 }
}
