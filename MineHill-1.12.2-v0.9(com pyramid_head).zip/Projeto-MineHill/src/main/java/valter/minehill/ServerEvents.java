package valter.minehill;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
public class ServerEvents {
 @SubscribeEvent public void naturalSpawn(net.minecraftforge.event.entity.living.LivingSpawnEvent.CheckSpawn e){
  if(!Settings.enabled || e.getWorld().provider.getDimension()!=0 || !Rules.night(e.getWorld().getWorldTime()))return;
  EntityLivingBase mob=e.getEntityLiving();
  if(mob instanceof IMob && !(mob instanceof StoneWatcher) && !(mob instanceof PyramidHead) && !(mob instanceof net.minecraft.entity.monster.EntityWitherSkeleton) && !(mob instanceof net.minecraft.entity.monster.EntityBlaze) && !(mob instanceof net.minecraft.entity.monster.EntityMagmaCube) && !(mob instanceof net.minecraft.entity.monster.EntityGhast) && !(mob instanceof net.minecraft.entity.monster.EntityPigZombie))e.setResult(net.minecraftforge.fml.common.eventhandler.Event.Result.DENY);
 }
 private boolean audible(WorldServer w,EntityPlayerMP p,EntityLivingBase mob){
  if(mob instanceof ChildGhost)return false;
  if(mob instanceof StoneWatcher && !((StoneWatcher)mob).awake())return false;
  if(!Rules.radioHeight(mob.posY-p.posY))return false;
  BlockPos pe=new BlockPos(p.posX,p.posY+p.getEyeHeight(),p.posZ),me=new BlockPos(mob.posX,mob.posY+mob.getEyeHeight(),mob.posZ);
  boolean playerUnder=w.getLightFor(EnumSkyBlock.SKY,pe)==0 && w.getHeight(pe).getY()>pe.getY()+3;
  boolean mobUnder=w.getLightFor(EnumSkyBlock.SKY,me)==0 && w.getHeight(me).getY()>me.getY()+3;
  // A ceiling between a surface player and a cave mob must not trigger the radio.
  // Within a cave the vertical band still prevents alarms from distant floors.
  return Rules.radioLayer(playerUnder,mobUnder,p.canEntityBeSeen(mob),mob.posY-p.posY);
 }
 @SubscribeEvent public void tick(TickEvent.WorldTickEvent e){
  if(e.phase!=TickEvent.Phase.END || e.world.isRemote || e.world.provider.getDimension()!=0 || !Settings.enabled)return;
  WorldServer w=(WorldServer)e.world;
  NightMobs.update(w);
  if(w.getGameRules().getBoolean("doDaylightCycle") && w.getTotalWorldTime()%2==0)w.setWorldTime(w.getWorldTime()-1);
  if(w.getTotalWorldTime()%10!=0)return;HauntData data=HauntData.get(w);
  if(w.getTotalWorldTime()%20==0)StoneWatcher.populate(w,data);
  long day=Math.floorDiv(w.getWorldTime(),24000L);
  boolean alarm=w.getGameRules().getBoolean("doDaylightCycle") && Rules.alarmWindow(w.getWorldTime()) && data.alarmDay!=day && w.playerEntities.stream().anyMatch(p->!p.isSpectator());
  if(alarm){data.alarmDay=day;data.markDirty();}
  for(net.minecraft.entity.player.EntityPlayer base:w.playerEntities){if(!(base instanceof EntityPlayerMP))continue;EntityPlayerMP p=(EntityPlayerMP)base;
   if(p.isSpectator()){MineHill.network.sendTo(new Pulse(0,0),p);continue;}
   double nearest=32;
   for(EntityLivingBase mob:w.getEntitiesWithinAABB(EntityLivingBase.class,p.getEntityBoundingBox().grow(32,8,32),x->x!=null && x.isEntityAlive() && x instanceof IMob))if(audible(w,p,mob))nearest=Math.min(nearest,p.getDistance(mob));
   int cue=alarm?3:0;
   if(cue==0 && Settings.childSoundsEnabled)for(long key:data.houses){BlockPos hp=BlockPos.fromLong(key);if(Math.abs(p.posY-hp.getY())<=5 && Rules.house(p.posX-hp.getX(),p.posZ-hp.getZ())){if(data.hear(p.getUniqueID(),"house:"+key)){cue=1;break;}}}
   MineHill.network.sendTo(new Pulse(Rules.threat(nearest),cue),p);
  }
 }
}
