package valter.minehill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.MovingSound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
public class ClientProxy extends CommonProxy {
 private final DynamicTorch torch=new DynamicTorch();private final NightLightmap darkness=new NightLightmap();private Float previousMusic=null,previousGamma=null;
 private float threat=0;private long lastPacket=0;private Radio radio;private Integer oldDistance=null;private int radioRetryTicks=0;
 @Override public void init(){MinecraftForge.EVENT_BUS.register(this);net.minecraftforge.fml.client.registry.RenderingRegistry.registerEntityRenderingHandler(StoneWatcher.class,StoneWatcherRenderer::new);net.minecraftforge.fml.client.registry.RenderingRegistry.registerEntityRenderingHandler(ChildGhost.class,ChildGhostRenderer::new);net.minecraftforge.fml.client.registry.RenderingRegistry.registerEntityRenderingHandler(PyramidHead.class,PyramidRenderer::new);}
 @Override public void receive(float level,int cue){Minecraft.getMinecraft().addScheduledTask(()->{
 Minecraft mc=Minecraft.getMinecraft();if(mc.world==null)return;threat=Math.max(0,Math.min(1,level));lastPacket=System.currentTimeMillis();
 if(cue>0 && mc.player!=null)mc.getSoundHandler().playSound(new PositionedSoundRecord((cue==3?MineHill.ALARM:cue==1?MineHill.CRY:MineHill.LAUGH).getSoundName(),SoundCategory.AMBIENT,(cue==3?.85f:.7f),(cue==3?1f:.93f+mc.world.rand.nextFloat()*.14f),false,0,net.minecraft.client.audio.ISound.AttenuationType.NONE,0,0,0));});}
 @SubscribeEvent public void tick(TickEvent.ClientTickEvent e){if(e.phase!=TickEvent.Phase.END)return;Minecraft mc=Minecraft.getMinecraft();boolean active=Settings.enabled && mc.world!=null && mc.world.provider.getDimension()==0 && mc.player!=null;
 torch.tick(mc,active);
 if(active){if(previousMusic==null)previousMusic=mc.gameSettings.getSoundLevel(SoundCategory.MUSIC);if(mc.gameSettings.getSoundLevel(SoundCategory.MUSIC)!=0)mc.gameSettings.setSoundLevel(SoundCategory.MUSIC,0);
 if(Rules.night(mc.world.getWorldTime())){if(previousGamma==null)previousGamma=mc.gameSettings.gammaSetting;mc.gameSettings.gammaSetting=0;}else if(previousGamma!=null){mc.gameSettings.gammaSetting=previousGamma;previousGamma=null;darkness.reset(mc);}
 }
 if(!active){if(previousMusic!=null){mc.gameSettings.setSoundLevel(SoundCategory.MUSIC,previousMusic);previousMusic=null;}if(previousGamma!=null){mc.gameSettings.gammaSetting=previousGamma;previousGamma=null;}darkness.reset(mc);threat=0;if(radio!=null){mc.getSoundHandler().stopSound(radio);radio=null;}if(oldDistance!=null){mc.gameSettings.renderDistanceChunks=oldDistance;oldDistance=null;mc.renderGlobal.loadRenderers();}return;}
 if(oldDistance==null)oldDistance=mc.gameSettings.renderDistanceChunks;
 if(mc.gameSettings.renderDistanceChunks!=2){mc.gameSettings.renderDistanceChunks=2;mc.renderGlobal.loadRenderers();}
 if(System.currentTimeMillis()-lastPacket>2500)threat=0;
 if(threat>0){
 if(radio==null){radio=new Radio();mc.getSoundHandler().playSound(radio);radioRetryTicks=0;}
 else if(++radioRetryTicks>=40){radioRetryTicks=0;if(!mc.getSoundHandler().isSoundPlaying(radio)){mc.getSoundHandler().stopSound(radio);radio=new Radio();mc.getSoundHandler().playSound(radio);}}
 }
 if(threat<=0 && radio!=null){mc.getSoundHandler().stopSound(radio);radio=null;}
 }
 @SubscribeEvent public void color(EntityViewRenderEvent.FogColors e){Minecraft mc=Minecraft.getMinecraft();if(mc.world!=null && mc.world.provider.getDimension()==0 && Settings.enabled){boolean n=Rules.night(mc.world.getWorldTime());e.setRed(n?.003f:.61f);e.setGreen(n?.003f:.63f);e.setBlue(n?.005f:.65f);if(n)darkness.apply(mc);}}
 @SubscribeEvent public void fog(EntityViewRenderEvent.FogDensity e){Minecraft mc=Minecraft.getMinecraft();if(mc.world!=null && mc.world.provider.getDimension()==0 && Settings.enabled){GlStateManager.setFog(GlStateManager.FogMode.EXP);boolean held=mc.player!=null && mc.player.getHeldItemOffhand().getItem()==net.minecraft.item.Item.getItemFromBlock(net.minecraft.init.Blocks.TORCH);e.setDensity(Rules.night(mc.world.getWorldTime()) && held?.055f:.105f);e.setCanceled(true);}}
 @SubscribeEvent public void music(net.minecraftforge.client.event.sound.PlaySoundEvent e){Minecraft mc=Minecraft.getMinecraft();if(Settings.enabled && mc.world!=null && mc.world.provider.getDimension()==0 && e.getSound()!=null && e.getSound().getCategory()==SoundCategory.MUSIC)e.setResultSound(null);}
 @Override public void ghostSound(ChildGhost ghost){Minecraft.getMinecraft().getSoundHandler().playSound(new GhostLaugh(ghost));}
 private static final class GhostLaugh extends MovingSound {
  private final ChildGhost ghost;
  GhostLaugh(ChildGhost entity){super(MineHill.GHOST_LAUGH,SoundCategory.AMBIENT);ghost=entity;repeat=true;repeatDelay=0;volume=.85f;pitch=1f;xPosF=(float)ghost.posX;yPosF=(float)ghost.posY;zPosF=(float)ghost.posZ;}
  @Override public void update(){if(ghost.isDead||ghost.ticksExisted>=105||Minecraft.getMinecraft().world!=ghost.world){donePlaying=true;return;}xPosF=(float)ghost.posX;yPosF=(float)ghost.posY;zPosF=(float)ghost.posZ;}
 }
 private class Radio extends MovingSound {
 private final java.util.Random random=new java.util.Random();private float flutter=.5f;private int ticks;
 Radio(){super(MineHill.RADIO,SoundCategory.HOSTILE);repeat=true;repeatDelay=0;attenuationType=net.minecraft.client.audio.ISound.AttenuationType.NONE;volume=(float)Settings.radioVolume*Math.max(.04f,(.08f+.92f*threat)*.5f);}
 @Override public void update(){Minecraft mc=Minecraft.getMinecraft();if(mc.world==null || mc.player==null || threat<=0){donePlaying=true;return;}if(++ticks%3==0)flutter=.15f+random.nextFloat()*.85f;float target=(float)Settings.radioVolume*(.08f+.92f*threat)*flutter;volume+=(target-volume)*.3f;pitch=.85f+random.nextFloat()*.3f;}
 }
}
