package valter.minehill;
import com.google.gson.Gson;
import java.io.*;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
/** Triangulated from the supplied FBX, split into independent animated parts. */
public final class PyramidModel extends ModelBase {
 private static final class Part {String kind;float[] pivot;float[][] vertices;}
 private Part[] parts;
 public PyramidModel(){
  try(Reader reader=new InputStreamReader(Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation(MineHill.ID,"models/entity/pyramid_head.json")).getInputStream(),StandardCharsets.UTF_8)){parts=new Gson().fromJson(reader,Part[].class);}
  catch(IOException e){throw new IllegalStateException("Missing Pyramid Head mesh",e);}
 }
 @Override public void render(Entity entity,float swing,float amount,float age,float yaw,float pitch,float scale){
  PyramidHead hunter=(PyramidHead)entity;float phase=(Math.abs(swing%13f-6.5f)-3.25f)/3.25f;
  float walk=phase*Math.min(.65f,amount)*85.9437f;
  float strike=(float)Math.sin((1-hunter.strike(0))*Math.PI)*100;
  for(Part part:parts){
   float angle=0;
   if("rightLeg".equals(part.kind))angle=walk;
   if("leftLeg".equals(part.kind))angle=-walk;
   if("leftArm".equals(part.kind))angle=-walk*.35f;
   if("swordArm".equals(part.kind))angle=hunter.strike(0)>0?-strike:walk*.12f;
   GlStateManager.pushMatrix();
   GlStateManager.translate(part.pivot[0]*scale,part.pivot[1]*scale,part.pivot[2]*scale);
   GlStateManager.rotate(angle,1,0,0);GlStateManager.translate(-part.pivot[0]*scale,-part.pivot[1]*scale,-part.pivot[2]*scale);
   BufferBuilder b=Tessellator.getInstance().getBuffer();b.begin(4,DefaultVertexFormats.POSITION_TEX_NORMAL);
   for(int i=0;i<part.vertices.length;i+=3){
    float[] a=part.vertices[i],c=part.vertices[i+1],d=part.vertices[i+2];float ux=c[0]-a[0],uy=c[1]-a[1],uz=c[2]-a[2],vx=d[0]-a[0],vy=d[1]-a[1],vz=d[2]-a[2];
    float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,length=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);if(length<.00001f)length=1;
    for(int j=0;j<3;j++){float[] v=part.vertices[i+j];b.pos(v[0]*scale,v[1]*scale,v[2]*scale).tex(v[3],v[4]).normal(nx/length,ny/length,nz/length).endVertex();}
   }Tessellator.getInstance().draw();GlStateManager.popMatrix();
  }
 }
}
