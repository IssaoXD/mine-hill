package valter.minehill;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Five-second spectral run around its witness; phasing avoids getting stuck in ruins. */
public final class ChildGhost extends EntityZombie {
 private UUID witness;private int age;private double startAngle;private boolean soundStarted;
 public ChildGhost(World w){super(w);setChild(true);setSilent(true);setNoAI(true);setNoGravity(true);noClip=true;experienceValue=0;}
 @Override protected void initEntityAI(){}
 public void appear(BlockPos point,EntityPlayer player){witness=player.getUniqueID();startAngle=Math.atan2(point.getZ()+.5-player.posZ,point.getX()+.5-player.posX);}
 @Override public void onLivingUpdate(){
  if(world.isRemote){if(!soundStarted){soundStarted=true;if(Settings.childSoundsEnabled)MineHill.proxy.ghostSound(this);}}
  else {
   EntityPlayer p=witness==null?null:world.getPlayerEntityByUUID(witness);
   if(!Settings.enabled||!Settings.ghostsEnabled||!Rules.night(world.getWorldTime())||p==null||p.isDead||p.isSpectator()||age>=100||getDistanceSq(p)>2304){setDead();return;}
   double a=startAngle+age*Math.PI*2/80.0,r=3.4;
   double x=p.posX+Math.cos(a)*r,z=p.posZ+Math.sin(a)*r;
   if(!world.isBlockLoaded(new BlockPos(x,p.posY,z))){setDead();return;}
   setPosition(x,p.posY+.06+Math.sin(age*.55)*.035,z);
   rotationYaw=(float)Math.toDegrees(a);renderYawOffset=rotationYaw;rotationYawHead=rotationYaw;
   age++;extinguish();
  }
  motionX=motionY=motionZ=0;super.onLivingUpdate();limbSwingAmount=prevLimbSwingAmount=.8f;limbSwing+=.8f;
 }
 @Override public boolean attackEntityFrom(DamageSource source,float amount){return false;}
 @Override public boolean attackEntityAsMob(Entity target){return false;}
 @Override public boolean canBePushed(){return false;}
 @Override public boolean canBeCollidedWith(){return false;}
 @Override public void applyEntityCollision(Entity entity){}
 @Override protected boolean canDespawn(){return false;}
 @Override protected SoundEvent getAmbientSound(){return null;}
 @Override protected SoundEvent getHurtSound(DamageSource source){return null;}
 @Override protected SoundEvent getDeathSound(){return null;}
 @Override public void writeEntityToNBT(NBTTagCompound n){super.writeEntityToNBT(n);if(witness!=null)n.setUniqueId("GhostWitness",witness);n.setInteger("GhostAgeV7",age);n.setDouble("GhostAngle",startAngle);}
 @Override public void readEntityFromNBT(NBTTagCompound n){super.readEntityFromNBT(n);setChild(true);setNoAI(true);setNoGravity(true);noClip=true;if(n.hasUniqueId("GhostWitness"))witness=n.getUniqueId("GhostWitness");age=n.hasKey("GhostAgeV7")?n.getInteger("GhostAgeV7"):100;startAngle=n.getDouble("GhostAngle");}
}
