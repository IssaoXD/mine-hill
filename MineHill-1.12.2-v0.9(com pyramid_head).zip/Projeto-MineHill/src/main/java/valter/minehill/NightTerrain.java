package valter.minehill;
import java.util.*;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.*;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.*;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.event.world.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.fml.common.gameevent.TickEvent;
/** Chunk-local reversible snapshots. Only exposed faces change; mining queues fresh faces. */
public class NightTerrain {
 private static final Map<World,Map<Long,Journal>> worlds=new WeakHashMap<>();
 private static final Map<World,LinkedHashSet<BlockPos>> pending=new WeakHashMap<>();
 private static class Entry {BlockPos pos;IBlockState before,after;Entry(BlockPos p,IBlockState b,IBlockState a){pos=p;before=b;after=a;}}
 private static class Journal {Chunk chunk;List<Entry> entries=new ArrayList<>();Set<Long> protectedPositions=new HashSet<>();long night=-1;int cursor,topCursor;Journal(Chunk c){chunk=c;}}
 private static Map<Long,Journal> map(World w){return worlds.computeIfAbsent(w,k->new LinkedHashMap<>());}
 private static long key(int x,int z){return ChunkPos.asLong(x,z);}
 private static Journal journal(Chunk c){return map(c.getWorld()).computeIfAbsent(key(c.x,c.z),k->new Journal(c));}
 @SubscribeEvent public void load(ChunkDataEvent.Load e){
  if(e.getWorld().isRemote || e.getWorld().provider.getDimension()!=0 || !e.getData().hasKey("MineHillOriginals",10))return;
  Journal j=new Journal(e.getChunk());NBTTagCompound n=e.getData().getCompoundTag("MineHillOriginals");j.night=n.hasKey("night")?n.getLong("night"):-1;
  if(n.getInteger("format")==5){j.cursor=Math.max(0,Math.min(65536,n.getInteger("cursor")));j.topCursor=Math.max(0,Math.min(256,n.getInteger("topCursor")));}
  NBTTagList list=n.getTagList("blocks",10);for(int i=0;i<list.tagCount();i++){NBTTagCompound v=list.getCompoundTagAt(i);BlockPos p=BlockPos.fromLong(v.getLong("p"));if((p.getX()>>4)!=j.chunk.x || (p.getZ()>>4)!=j.chunk.z)continue;
   Entry a=new Entry(p,NBTUtil.readBlockState(v.getCompoundTag("before")),NBTUtil.readBlockState(v.getCompoundTag("after")));j.entries.add(a);j.protectedPositions.add(p.toLong());}
  map(e.getWorld()).put(key(j.chunk.x,j.chunk.z),j);
 }
 @SubscribeEvent public void save(ChunkDataEvent.Save e){Map<Long,Journal> m=worlds.get(e.getWorld());if(m==null)return;Journal j=m.get(key(e.getChunk().x,e.getChunk().z));if(j==null)return;
  NBTTagCompound n=new NBTTagCompound();n.setInteger("format",5);n.setLong("night",j.night);n.setInteger("cursor",j.cursor);n.setInteger("topCursor",j.topCursor);NBTTagList list=new NBTTagList();
  for(Entry a:j.entries){NBTTagCompound v=new NBTTagCompound();v.setLong("p",a.pos.toLong());v.setTag("before",NBTUtil.writeBlockState(new NBTTagCompound(),a.before));v.setTag("after",NBTUtil.writeBlockState(new NBTTagCompound(),a.after));list.appendTag(v);}n.setTag("blocks",list);e.getData().setTag("MineHillOriginals",n);
 }
 @SubscribeEvent public void unload(WorldEvent.Unload e){worlds.remove(e.getWorld());pending.remove(e.getWorld());}
 public static boolean protectedAt(World w,BlockPos p){Map<Long,Journal> m=worlds.get(w);if(m==null)return false;Journal j=m.get(key(p.getX()>>4,p.getZ()>>4));return j!=null && j.protectedPositions.contains(p.toLong());}
 private void enqueue(World w,BlockPos p){if(w.isRemote || w.provider.getDimension()!=0 || !Settings.enabled || !Rules.night(w.getWorldTime()))return;LinkedHashSet<BlockPos> q=pending.computeIfAbsent(w,k->new LinkedHashSet<>());
  if(q.size()>8192)return;q.add(p.toImmutable());for(EnumFacing f:EnumFacing.values())q.add(p.offset(f));
 }
 // Do not cancel mining: after the block is actually gone its snapshot is forgotten.
 @SubscribeEvent(priority=EventPriority.LOWEST) public void breaking(BlockEvent.BreakEvent e){enqueue(e.getWorld(),e.getPos());}
 @SubscribeEvent(priority=EventPriority.LOWEST) public void placing(BlockEvent.PlaceEvent e){enqueue(e.getWorld(),e.getPos());}
 @SubscribeEvent(priority=EventPriority.LOWEST) public void multi(BlockEvent.MultiPlaceEvent e){for(net.minecraftforge.common.util.BlockSnapshot s:e.getReplacedBlockSnapshots())enqueue(e.getWorld(),s.getPos());}
 @SubscribeEvent public void explode(ExplosionEvent.Detonate e){e.getAffectedBlocks().removeIf(p->protectedAt(e.getWorld(),p));}
 private void forgetChanged(World w,BlockPos p){Map<Long,Journal> m=worlds.get(w);if(m==null)return;Journal j=m.get(key(p.getX()>>4,p.getZ()>>4));if(j==null || !j.protectedPositions.contains(p.toLong()))return;
  for(Iterator<Entry> it=j.entries.iterator();it.hasNext();){Entry a=it.next();if(a.pos.equals(p) && !matches(a,w.getBlockState(p))){it.remove();j.protectedPositions.remove(p.toLong());j.chunk.markDirty();break;}}
 }
 private boolean exposed(World w,BlockPos p){for(EnumFacing f:EnumFacing.values()){BlockPos q=p.offset(f);if(!w.isBlockLoaded(q))continue;IBlockState s=w.getBlockState(q);
  if(s.getMaterial()==Material.AIR || (!s.isOpaqueCube() && !s.getMaterial().isLiquid() && s.getBlock()!=MineHill.NIGHT_WATER))return true;
 }return false;}
 private boolean change(WorldServer w,BlockPos p,long cycle){if(p.getY()<1 || p.getY()>255 || !w.isBlockLoaded(p) || protectedAt(w,p))return false;
  IBlockState original=w.getBlockState(p),after=replacement(original);if(after==null || original.getBlock().hasTileEntity(original) || !exposed(w,p))return false;
  Journal j=journal(w.getChunkFromBlockCoords(p));if(j.night!=cycle && !j.entries.isEmpty())return false;j.night=cycle;
  Entry a=new Entry(p,original,after);j.entries.add(a);j.protectedPositions.add(p.toLong());
  if(!w.setBlockState(p,after,2)){j.entries.remove(j.entries.size()-1);j.protectedPositions.remove(p.toLong());return false;}j.chunk.markDirty();return true;
 }
 private double distance(World w,Journal j){double d=Double.MAX_VALUE;for(net.minecraft.entity.player.EntityPlayer p:w.playerEntities){double x=p.posX-(j.chunk.x*16+8),z=p.posZ-(j.chunk.z*16+8);d=Math.min(d,x*x+z*z);}return d;}
 @SubscribeEvent public void tick(TickEvent.WorldTickEvent e){
  if(e.phase!=TickEvent.Phase.END || e.world.isRemote || e.world.provider.getDimension()!=0)return;WorldServer w=(WorldServer)e.world;
  boolean night=Settings.enabled && Rules.night(w.getWorldTime());long cycle=Math.floorDiv(w.getWorldTime(),24000);
  Set<Journal> active=new HashSet<>();if(night)for(net.minecraft.entity.player.EntityPlayer p:w.playerEntities)for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++){
   Chunk c=w.getChunkProvider().getLoadedChunk(p.chunkCoordX+dx,p.chunkCoordZ+dz);if(c!=null)active.add(journal(c));}
  Map<Long,Journal> m=worlds.get(w);if(m==null)return;int budget=Settings.scanBudget,changes=0;long deadline=System.nanoTime()+2000000L;
  LinkedHashSet<BlockPos> q=pending.get(w);
  if(night && q!=null)for(Iterator<BlockPos> it=q.iterator();it.hasNext() && budget>0 && changes<Settings.maxChangesPerTick && System.nanoTime()<deadline;){BlockPos p=it.next();it.remove();budget--;if(!w.isBlockLoaded(p))continue;forgetChanged(w,p);if(change(w,p,cycle))changes++;}
  if(!night && q!=null)q.clear();
  List<Journal> work=new ArrayList<>(m.values());work.sort(Comparator.comparingDouble(j->distance(w,j)));
  for(Journal j:work){if(w.getChunkProvider().getLoadedChunk(j.chunk.x,j.chunk.z)!=j.chunk){m.remove(key(j.chunk.x,j.chunk.z));continue;}
   if(budget<=0 || changes>=Settings.maxChangesPerTick || System.nanoTime()>=deadline)break;
   if(!night || j.night!=cycle){while(budget>0 && changes<Settings.maxChangesPerTick && System.nanoTime()<deadline && !j.entries.isEmpty()){
    Entry a=j.entries.remove(j.entries.size()-1);if(matches(a,w.getBlockState(a.pos)))w.setBlockState(a.pos,a.before,2);j.protectedPositions.remove(a.pos.toLong());j.chunk.markDirty();budget--;changes++;
   }if(j.entries.isEmpty()){j.cursor=0;j.topCursor=0;j.night=cycle;}}
   if(!night || j.night!=cycle || !active.contains(j))continue;
   // Surface first, then discover exposed cave walls. Hidden blocks are only read, never replaced.
   while(budget>0 && changes<Settings.maxChangesPerTick && System.nanoTime()<deadline && (j.topCursor<256 || j.cursor<65536)){
    int x,z,y;budget--;
    if(j.topCursor<256){int col=j.topCursor++;x=(j.chunk.x<<4)+(col&15);z=(j.chunk.z<<4)+(col>>4);y=j.chunk.getHeightValue(x&15,z&15)-1;}
    else {int c=j.cursor,col=c>>8,depth=c&255;x=(j.chunk.x<<4)+(col&15);z=(j.chunk.z<<4)+(col>>4);int top=Math.min(255,j.chunk.getHeightValue(x&15,z&15)-1);
     if(depth<255-top){j.cursor=(col<<8)+(255-top);continue;}j.cursor++;y=255-depth;
    }
    if(change(w,new BlockPos(x,y,z),cycle))changes++;
   }
  }
 }
 private static boolean matches(Entry a,IBlockState current){return current.equals(a.after) || (a.before.getBlock()==Blocks.TORCH && a.after.getBlock()==Blocks.REDSTONE_TORCH && (current.getBlock()==Blocks.REDSTONE_TORCH || current.getBlock()==Blocks.UNLIT_REDSTONE_TORCH) && current.getValue(net.minecraft.block.BlockTorch.FACING)==a.after.getValue(net.minecraft.block.BlockTorch.FACING));}
 private IBlockState replacement(IBlockState s){Block b=s.getBlock();
  if(b instanceof net.minecraft.block.BlockFence && s.getMaterial()==Material.WOOD)return Blocks.IRON_BARS.getDefaultState();
  if(b==Blocks.TORCH)return Blocks.REDSTONE_TORCH.getDefaultState().withProperty(net.minecraft.block.BlockTorch.FACING,s.getValue(net.minecraft.block.BlockTorch.FACING));
  if(b==Blocks.WATER || b==Blocks.FLOWING_WATER)return MineHill.NIGHT_WATER.getDefaultState();
  if(b==Blocks.GRASS||b==Blocks.DIRT||b==Blocks.MYCELIUM||b==Blocks.SAND||b==Blocks.GRAVEL)return Blocks.NETHERRACK.getDefaultState();
  if(b==Blocks.STONE||b==Blocks.COBBLESTONE||b==Blocks.MOSSY_COBBLESTONE)return Blocks.NETHER_BRICK.getDefaultState();
  if(b==Blocks.LOG||b==Blocks.LOG2)return Blocks.RED_NETHER_BRICK.getDefaultState();if(b==Blocks.LEAVES||b==Blocks.LEAVES2)return Blocks.NETHER_WART_BLOCK.getDefaultState();return null;
 }
}
