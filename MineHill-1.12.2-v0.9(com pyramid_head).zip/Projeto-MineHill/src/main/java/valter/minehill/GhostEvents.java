package valter.minehill;

import java.util.*;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Bounded checks in already-loaded settlements. Never generates chunks for a scare. */
public final class GhostEvents {
 private final Map<World,Map<UUID,Long>> timers=new WeakHashMap<>();
 @SubscribeEvent public void tick(TickEvent.WorldTickEvent event){
  if(event.phase!=TickEvent.Phase.END||event.world.isRemote||event.world.provider.getDimension()!=0)return;
  WorldServer world=(WorldServer)event.world;
  if(!Settings.enabled||!Settings.ghostsEnabled||!Rules.night(world.getWorldTime())||world.getTotalWorldTime()%100!=0)return;
  long now=world.getTotalWorldTime();Map<UUID,Long> cooldown=timers.computeIfAbsent(world,w->new HashMap<>());
  Set<UUID> online=new HashSet<>();for(EntityPlayer p:world.playerEntities)online.add(p.getUniqueID());cooldown.keySet().retainAll(online);
  int total=0;for(net.minecraft.entity.Entity e:world.loadedEntityList)if(e instanceof ChildGhost && !e.isDead)total++;
  if(total>=3)return;
  HauntData data=HauntData.get(world);
  for(EntityPlayer player:world.playerEntities){
   if(player.isSpectator())continue;
   Long next=cooldown.get(player.getUniqueID());
   if(next==null){cooldown.put(player.getUniqueID(),now+300);continue;}
   if(now<next)continue;
   cooldown.put(player.getUniqueID(),now+300+world.rand.nextInt(300));
   if(!world.getEntitiesWithinAABB(ChildGhost.class,player.getEntityBoundingBox().grow(48)).isEmpty())continue;
   List<BlockPos> homes=new ArrayList<>();
   for(long key:data.watcherHomes){BlockPos p=BlockPos.fromLong(key);if(player.getDistanceSq(p)<=2304 && Math.abs(player.posY-p.getY())<=6 && world.isBlockLoaded(p))homes.add(p);if(homes.size()>=32)break;}
   if(homes.size()<2)continue;
   if(spawnInFront(world,player)){
    cooldown.put(player.getUniqueID(),now+Settings.ghostCooldownSeconds*20L+world.rand.nextInt(801));total++;
   }
   if(total>=3)return;
  }
 }
 public static boolean spawnInFront(WorldServer world,EntityPlayer player){
  if(!Rules.night(world.getWorldTime())||world.getDifficulty()==net.minecraft.world.EnumDifficulty.PEACEFUL)return false;
  double yaw=Math.toRadians(player.rotationYaw),fx=-Math.sin(yaw),fz=Math.cos(yaw);
  for(int attempt=0;attempt<8;attempt++){
   double side=attempt==0?0:world.rand.nextDouble()*3-1.5;
   int x=(int)Math.floor(player.posX+fx*3.4+fz*side),z=(int)Math.floor(player.posZ+fz*3.4-fx*side);
   BlockPos point=walkable(world,x,z,(int)player.posY);
   if(point==null)continue;
   ChildGhost ghost=new ChildGhost(world);ghost.appear(point,player);ghost.setLocationAndAngles(x+.5,point.getY(),z+.5,player.rotationYaw+90,0);
   if(!player.canEntityBeSeen(ghost))continue;
   if(world.spawnEntity(ghost))return true;
  }return false;
 }
 static BlockPos walkable(World world,int x,int z,int aroundY){
  // Stay on the player's floor: roofs and deep cave floors are not spawn candidates.
  for(int dy=3;dy>=-4;dy--){BlockPos p=new BlockPos(x,aroundY+dy,z);
   if(p.getY()<2||p.getY()>252||!world.isBlockLoaded(p)||!world.isBlockLoaded(p.up())||!world.isBlockLoaded(p.down()))continue;
   if(world.isAirBlock(p)&&world.isAirBlock(p.up())&&world.getBlockState(p.down()).isSideSolid(world,p.down(),EnumFacing.UP))return p;
  }
  return null;
 }
}
