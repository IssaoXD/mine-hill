package valter.minehill;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.util.ResourceLocation;
public final class PyramidRenderer extends RenderLiving<PyramidHead> {
 private static final ResourceLocation SKIN=new ResourceLocation(MineHill.ID,"textures/entity/pyramid_atlas.png");
 public PyramidRenderer(RenderManager manager){super(manager,new PyramidModel(),.65f);}
 @Override protected ResourceLocation getEntityTexture(PyramidHead entity){return SKIN;}
}
