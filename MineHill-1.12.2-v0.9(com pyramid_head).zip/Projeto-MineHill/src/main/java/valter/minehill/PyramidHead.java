package valter.minehill;
import java.util.UUID;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;

public final class PyramidHead extends EntityCreature implements IMob {
 private UUID owner;private int attackTicks,teleportWait;
 public PyramidHead(World w){super(w);setSize(.85f,2.8f);enablePersistence();experienceValue=0;}
 public void bind(UUID id){owner=id;}public UUID owner(){return owner;}
 @Override protected void initEntityAI(){tasks.addTask(0,new EntityAISwimming(this));tasks.addTask(1,new EntityAIAttackMelee(this,1.0,true));}
 @Override protected void applyEntityAttributes(){super.applyEntityAttributes();getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(200);getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(.23);getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64);getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(1);getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(8);}
 @Override public void onLivingUpdate(){
  if(attackTicks>0)attackTicks--;
  if(!world.isRemote){
   GuiltData d=GuiltData.get(world);d.phase(world.getWorldTime());EntityPlayer player=owner==null?null:world.getPlayerEntityByUUID(owner);GuiltData.Entry record=owner==null?null:d.entry(owner);
   if(!Settings.enabled||!Settings.pyramidEnabled||world.provider.getDimension()!=0||player==null||player.isDead||player.isSpectator()||!d.allowed(owner,world.getWorldTime())||record==null||!getUniqueID().equals(record.entity)){setDead();return;}
   getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(GuiltRules.speed(record.kills));
   setAttackTarget(player);extinguish();
   if(--teleportWait<=0){teleportWait=40;
    Vec3d delta=getPositionVector().subtract(player.getPositionEyes(1));Vec3d look=player.getLookVec();
    boolean seen=getDistanceSq(player)<784&&player.canEntityBeSeen(this)&&look.dotProduct(delta.normalize())>.15;
    if(!seen&&getDistanceSq(player)>36){BlockPos spot=PyramidEvents.behind(world,player,8,height);if(spot!=null){setPositionAndUpdate(spot.getX()+.5,spot.getY(),spot.getZ()+.5);getNavigator().clearPath();}}
   }
  }super.onLivingUpdate();
 }
 @Override public boolean attackEntityAsMob(Entity target){if(attackTicks>0||owner==null||!owner.equals(target.getUniqueID()))return false;attackTicks=30;world.setEntityState(this,(byte)4);playSound(SoundEvents.ENTITY_IRONGOLEM_ATTACK,.8f,.7f);return target.attackEntityFrom(DamageSource.causeMobDamage(this),8);}
 @Override public void handleStatusUpdate(byte id){if(id==4)attackTicks=30;else super.handleStatusUpdate(id);}
 public float strike(float partial){return Math.max(0,Math.min(1,(attackTicks-partial)/30f));}
 @Override protected void playStepSound(BlockPos pos,net.minecraft.block.Block block){playSound(SoundEvents.ENTITY_IRONGOLEM_STEP,1f,.9f);}
 @Override protected boolean canDespawn(){return false;}
 @Override public void writeEntityToNBT(NBTTagCompound n){super.writeEntityToNBT(n);if(owner!=null)n.setUniqueId("GuiltOwner",owner);}
 @Override public void readEntityFromNBT(NBTTagCompound n){super.readEntityFromNBT(n);if(n.hasUniqueId("GuiltOwner"))owner=n.getUniqueId("GuiltOwner");}
}
