package valter.minehill;
public class CommonProxy { public void ghostSound(ChildGhost ghost){}
 public void init(){} public void receive(float threat,int cue){} }
