package valter.minehill;
import java.util.*;
import net.minecraft.nbt.*;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldSavedData;
/** Persistent guilt. Each cycle starts at the warning siren, not dawn. */
public final class GuiltData extends WorldSavedData {
 public static final class Entry {public int kills;public UUID entity;public long respawnAt;public boolean carried;}
 private final Map<UUID,Entry> players=new HashMap<>();private long cycle=Long.MIN_VALUE;
 public GuiltData(){super("minehill_guilt");}public GuiltData(String name){super(name);}
 public static GuiltData get(World w){GuiltData d=(GuiltData)w.getPerWorldStorage().getOrLoadData(GuiltData.class,"minehill_guilt");if(d==null){d=new GuiltData();w.getPerWorldStorage().setData("minehill_guilt",d);}return d;}
 public void phase(long time){long now=GuiltRules.day(time);if(cycle==Long.MIN_VALUE){cycle=now;markDirty();return;}if(cycle==now)return;
  long elapsed=now-cycle;Iterator<Entry> it=players.values().iterator();while(it.hasNext()){Entry e=it.next();if(elapsed==1&&e.kills>=10){e.kills=5;e.carried=true;}else it.remove();}cycle=now;markDirty();
 }
 public Entry entry(UUID id){return players.get(id);}
 public boolean active(UUID id){Entry e=entry(id);return e!=null&&GuiltRules.triggered(e.kills);}
 public boolean allowed(UUID id,long time){Entry e=entry(id);return active(id)&&(GuiltRules.daytime(time)||e.carried);}
 public void kill(UUID id,long time){phase(time);if(!GuiltRules.daytime(time)&&!allowed(id,time))return;Entry e=players.computeIfAbsent(id,k->new Entry());e.kills=GuiltRules.next(e.kills);markDirty();}
 public void defeated(UUID owner,UUID entity,long totalTime){Entry e=entry(owner);if(e!=null&&entity.equals(e.entity)){e.entity=null;e.respawnAt=totalTime+1200;markDirty();}}
 public void reset(UUID id){if(players.remove(id)!=null)markDirty();}
 public void assign(UUID owner,UUID entity){Entry e=entry(owner);if(e!=null){e.entity=entity;markDirty();}}
 @Override public void readFromNBT(NBTTagCompound n){players.clear();cycle=n.getInteger("schema")==2?n.getLong("cycle"):Long.MIN_VALUE;NBTTagList a=n.getTagList("players",10);for(int i=0;i<a.tagCount();i++){NBTTagCompound v=a.getCompoundTagAt(i);if(!v.hasUniqueId("owner"))continue;Entry e=new Entry();e.kills=Math.max(0,v.getInteger("kills"));e.carried=v.getBoolean("carried");e.respawnAt=v.getLong("respawnAt");if(v.hasUniqueId("entity"))e.entity=v.getUniqueId("entity");players.put(v.getUniqueId("owner"),e);}}
 @Override public NBTTagCompound writeToNBT(NBTTagCompound n){n.setInteger("schema",2);n.setLong("cycle",cycle);NBTTagList a=new NBTTagList();players.forEach((id,e)->{NBTTagCompound v=new NBTTagCompound();v.setUniqueId("owner",id);v.setInteger("kills",e.kills);v.setBoolean("carried",e.carried);v.setLong("respawnAt",e.respawnAt);if(e.entity!=null)v.setUniqueId("entity",e.entity);a.appendTag(v);});n.setTag("players",a);return n;}
}
