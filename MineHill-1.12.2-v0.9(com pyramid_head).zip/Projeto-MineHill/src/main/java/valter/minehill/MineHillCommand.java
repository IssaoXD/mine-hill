package valter.minehill;
import net.minecraft.command.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.text.TextComponentString;
public class MineHillCommand extends CommandBase {
 public String getName(){return "minehill";}
 public String getUsage(ICommandSender s){return "/minehill status | reset_sounds | test_ghost | test_pyramid | reset_guilt";}
 public int getRequiredPermissionLevel(){return 2;}
 public void execute(MinecraftServer server,ICommandSender sender,String[] args)throws CommandException{
 if(args.length==1 && args[0].equals("test_ghost")){EntityPlayerMP p=getCommandSenderAsPlayer(sender);boolean ok=GhostEvents.spawnInFront(p.getServerWorld(),p);sender.sendMessage(new TextComponentString(ok?"Mine Hill: aparição de teste por 5 segundos.":"Precisa ser noite, fora do Pacífico, com espaço livre à frente."));return;}
 if(args.length==1 && args[0].equals("test_pyramid")){EntityPlayerMP p=getCommandSenderAsPlayer(sender);if(!GuiltRules.daytime(p.world.getWorldTime())){sender.sendMessage(new TextComponentString("Teste disponível durante o dia, antes da sirene."));return;}GuiltData d=GuiltData.get(p.world);for(int i=0;i<5;i++)d.kill(p.getUniqueID(),p.world.getWorldTime());sender.sendMessage(new TextComponentString("Mine Hill: perseguição de teste ativada."));return;}
 if(args.length==1 && args[0].equals("reset_guilt")){EntityPlayerMP p=getCommandSenderAsPlayer(sender);GuiltData.get(p.world).reset(p.getUniqueID());sender.sendMessage(new TextComponentString("Mine Hill: culpa e perseguição encerradas."));return;}
 if(args.length==1 && args[0].equals("reset_sounds")){EntityPlayerMP p=getCommandSenderAsPlayer(sender);HauntData.get(p.getServerWorld()).reset(p.getUniqueID());sender.sendMessage(new TextComponentString("Mine Hill: seus eventos de som foram liberados novamente."));return;}
 sender.sendMessage(new TextComponentString("Mine Hill 0.9.0 beta | enabled="+Settings.enabled+" | childSoundsEnabled="+Settings.childSoundsEnabled+" | ghostsEnabled="+Settings.ghostsEnabled+" | exposedTerrain=true"+" | villageRegionChunks="+Settings.regionChunks+" | maxChangesPerTick="+Settings.maxChangesPerTick));
 }
}
