package valter.minehill;
import java.util.*;
import net.minecraft.entity.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public final class PyramidEvents {
 @SubscribeEvent public void death(LivingDeathEvent event){
  World w=event.getEntityLiving().world;if(w.isRemote||w.provider.getDimension()!=0)return;
  EntityLivingBase victim=event.getEntityLiving();GuiltData d=GuiltData.get(w);d.phase(w.getWorldTime());
  if(victim instanceof EntityPlayer)return;
  if(victim instanceof PyramidHead){UUID owner=((PyramidHead)victim).owner();if(owner!=null)d.defeated(owner,victim.getUniqueID(),w.getTotalWorldTime());return;}
  if(!Settings.enabled||!Settings.pyramidEnabled)return;
  Entity killer=event.getSource().getTrueSource();
  if(killer instanceof EntityPlayer && !((EntityPlayer)killer).isSpectator() && peaceful(victim))d.kill(killer.getUniqueID(),w.getWorldTime());
 }
 static boolean peaceful(EntityLivingBase e){return e instanceof EntityAnimal||e instanceof EntityVillager||e instanceof EntitySquid||e instanceof EntityBat;}
 @SubscribeEvent public void join(EntityJoinWorldEvent event){
  if(event.getWorld().isRemote||!(event.getEntity() instanceof PyramidHead))return;
  PyramidHead e=(PyramidHead)event.getEntity();GuiltData d=GuiltData.get(event.getWorld());d.phase(event.getWorld().getWorldTime());
  GuiltData.Entry record=e.owner()==null?null:d.entry(e.owner());
  if(!Settings.enabled||!Settings.pyramidEnabled||record==null||!d.allowed(e.owner(),event.getWorld().getWorldTime())||!e.getUniqueID().equals(record.entity))event.setCanceled(true);
 }
 @SubscribeEvent public void tick(TickEvent.WorldTickEvent event){
  if(event.phase!=TickEvent.Phase.END||event.world.isRemote||event.world.provider.getDimension()!=0)return;
  WorldServer w=(WorldServer)event.world;GuiltData data=GuiltData.get(w);data.phase(w.getWorldTime());
  if(!Settings.enabled||!Settings.pyramidEnabled||w.getDifficulty()==EnumDifficulty.PEACEFUL||w.getTotalWorldTime()%20!=0)return;
  Map<UUID,PyramidHead> loaded=new HashMap<>();
  for(Entity entity:w.loadedEntityList)if(entity instanceof PyramidHead&&!entity.isDead){PyramidHead p=(PyramidHead)entity;if(p.owner()!=null)loaded.put(p.owner(),p);}
  for(EntityPlayer player:w.playerEntities){
   if(player.isDead||player.isSpectator()||!data.allowed(player.getUniqueID(),w.getWorldTime()))continue;
   PyramidHead existing=loaded.get(player.getUniqueID());GuiltData.Entry record=data.entry(player.getUniqueID());
   if(existing!=null&&existing.getUniqueID().equals(record.entity))continue;
   if(w.getTotalWorldTime()<record.respawnAt)continue;
   BlockPos spot=behind(w,player,9,2.9);if(spot==null)continue;
   PyramidHead entity=new PyramidHead(w);entity.bind(player.getUniqueID());entity.setLocationAndAngles(spot.getX()+.5,spot.getY(),spot.getZ()+.5,player.rotationYaw,0);
   UUID old=record.entity;data.assign(player.getUniqueID(),entity.getUniqueID());if(!w.spawnEntity(entity))data.assign(player.getUniqueID(),old);
  }
 }
 static BlockPos behind(World w,EntityPlayer p,int distance,double height){
  double angle=Math.toRadians(p.rotationYaw),fx=-Math.sin(angle),fz=Math.cos(angle);
  for(int attempt=0;attempt<16;attempt++){
   int side=attempt==0?0:w.rand.nextInt(9)-4,back=distance+w.rand.nextInt(4);
   int x=(int)Math.floor(p.posX-fx*back+fz*side),z=(int)Math.floor(p.posZ-fz*back-fx*side);
   BlockPos spot=ground(w,x,z,(int)Math.floor(p.posY),height);
   if(spot!=null)return spot;
  }return null;
 }
 static BlockPos ground(World w,int x,int z,int y,double height){
  for(int dy=4;dy>=-6;dy--){BlockPos p=new BlockPos(x,y+dy,z);if(p.getY()<2||p.getY()>250||!w.isBlockLoaded(p)||!w.isBlockLoaded(p.up(3)))continue;
   if(!w.getBlockState(p.down()).isSideSolid(w,p.down(),net.minecraft.util.EnumFacing.UP))continue;
   AxisAlignedBB box=new AxisAlignedBB(x+.08,p.getY(),z+.08,x+.92,p.getY()+height,z+.92);
   if(w.getCollisionBoxes(null,box).isEmpty()&&!w.containsAnyLiquid(box))return p;
  }return null;
 }
}
