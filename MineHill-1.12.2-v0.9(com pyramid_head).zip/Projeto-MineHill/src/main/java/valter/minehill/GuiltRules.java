package valter.minehill;
public final class GuiltRules {
 private GuiltRules(){}
 public static boolean daytime(long time){long t=Math.floorMod(time,24000L);return t<12700||t>=23000;}
 public static long day(long time){return Math.floorDiv(time-12700L,24000L);}
 public static int next(int kills){return kills==Integer.MAX_VALUE?kills:Math.max(0,kills)+1;}
 public static boolean triggered(int kills){return kills>=5;}
 // Small linear steps; sprint-level ceiling starts only above ten kills.
 public static double speed(int kills){return .25+Math.min(6,Math.max(0,kills-5))*(.25/6.0);}
}
