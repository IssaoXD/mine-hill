package valter.minehill;

import net.minecraft.client.model.ModelZombie;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Baby-zombie proportions with an original dark, translucent skin; no armor layers. */
public final class ChildGhostRenderer extends RenderLiving<ChildGhost> {
 private static final ResourceLocation SKIN=new ResourceLocation(MineHill.ID,"textures/entity/child_ghost.png");
 public ChildGhostRenderer(RenderManager manager){super(manager,new ModelZombie(),0f);}
 @Override protected ResourceLocation getEntityTexture(ChildGhost entity){return SKIN;}
 @Override protected void renderModel(ChildGhost entity,float limbSwing,float limbAmount,float age,float headYaw,float headPitch,float scale){
  if(!bindEntityTexture(entity))return;
  GlStateManager.enableBlend();
  GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA,GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
  GlStateManager.alphaFunc(516,.01f);GlStateManager.depthMask(false);
  GlStateManager.disableTexture2D();GlStateManager.disableLighting();
  GlStateManager.color(.46f,.49f,.55f,.64f);
  try{mainModel.render(entity,limbSwing,limbAmount,age,headYaw,headPitch,scale);}
  finally{GlStateManager.enableLighting();GlStateManager.enableTexture2D();GlStateManager.color(1f,1f,1f,1f);GlStateManager.depthMask(true);GlStateManager.alphaFunc(516,.1f);GlStateManager.disableBlend();}
 }
}
