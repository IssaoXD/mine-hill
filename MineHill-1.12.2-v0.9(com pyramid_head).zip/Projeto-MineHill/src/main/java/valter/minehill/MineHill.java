package valter.minehill;
import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
@Mod(modid=MineHill.ID,name="Mine Hill",version="0.9.0-beta",acceptedMinecraftVersions="[1.12.2]")
@Mod.EventBusSubscriber(modid=MineHill.ID)
public class MineHill {
 public static final String ID="minehill";
 public static final NightWater NIGHT_WATER=new NightWater();
 public static final SoundEvent RADIO=sound("radio_static"),CRY=sound("child_cry"),LAUGH=sound("child_laugh"),ALARM=sound("alarm"),GHOST_LAUGH=sound("ghost_laugh");
 public static SimpleNetworkWrapper network;
 @SidedProxy(clientSide="valter.minehill.ClientProxy",serverSide="valter.minehill.CommonProxy") public static CommonProxy proxy;
 private static SoundEvent sound(String n){ResourceLocation id=new ResourceLocation(ID,n);return new SoundEvent(id).setRegistryName(id);}
 @Mod.EventHandler public void pre(FMLPreInitializationEvent e){
  Settings.load(e.getSuggestedConfigurationFile());
  net.minecraftforge.fml.common.registry.EntityRegistry.registerModEntity(new ResourceLocation(ID,"stone_watcher"),StoneWatcher.class,"stone_watcher",0,this,64,3,true);net.minecraftforge.fml.common.registry.EntityRegistry.registerModEntity(new ResourceLocation(ID,"child_ghost"),ChildGhost.class,"child_ghost",1,this,64,2,true);net.minecraftforge.fml.common.registry.EntityRegistry.registerModEntity(new ResourceLocation(ID,"pyramid_head"),PyramidHead.class,"pyramid_head",2,this,96,2,true);network=NetworkRegistry.INSTANCE.newSimpleChannel(ID);
  network.registerMessage(Pulse.Handler.class,Pulse.class,0,Side.CLIENT);
  MinecraftForge.EVENT_BUS.register(new PyramidEvents());MinecraftForge.EVENT_BUS.register(new GhostEvents());MinecraftForge.EVENT_BUS.register(new ServerEvents());MinecraftForge.EVENT_BUS.register(new NightTerrain());
  MinecraftForge.TERRAIN_GEN_BUS.register(new Villages());GameRegistry.registerWorldGenerator(new Villages(),100);proxy.init();
 }
 @Mod.EventHandler public void start(FMLServerStartingEvent e){e.registerServerCommand(new MineHillCommand());}
 @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> e){e.getRegistry().register(NIGHT_WATER);}
 @SubscribeEvent public static void items(RegistryEvent.Register<Item> e){e.getRegistry().register(new ItemBlock(NIGHT_WATER).setRegistryName(NIGHT_WATER.getRegistryName()));}
 @SubscribeEvent public static void sounds(RegistryEvent.Register<SoundEvent> e){e.getRegistry().registerAll(RADIO,CRY,LAUGH,ALARM,GHOST_LAUGH);}
}
